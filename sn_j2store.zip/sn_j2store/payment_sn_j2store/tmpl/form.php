<?php
defined('_JEXEC') or die('Restricted access'); 
?>

<div class="sn-j2store-on-selection-text"><?php echo JText::_($vars['onSelectionText']); ?></div>