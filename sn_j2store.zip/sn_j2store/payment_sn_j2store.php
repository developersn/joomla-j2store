<?php
defined('_JEXEC') or die('Restricted access');

require_once (JPATH_ADMINISTRATOR.'/components/com_j2store/library/plugins/payment.php');

jimport('sncore.include');

class plgJ2StorePayment_sn_j2store extends J2StorePaymentPlugin
{
    var $_element = 'payment_sn_j2store';
    public function __construct(& $subject, $config)
    {
        $this->loadLanguage('com_j2store',JPATH_ADMINISTRATOR);
        SNGlobal::loadLanguage('plg_j2store_payment_sn_j2store',JPATH_ADMINISTRATOR);

        parent::__construct($subject, $config);
    }

    /* Prepare the payment form before payment */
    function _prePayment($data)
    {
        $displayText = $this->params->get('display_name','پرداخت آنلاین');
        $onBeforePaymentText = $this->params->get('onbeforepayment','');
        $buttonText = $this->params->get('button_text','J2STORE_PLACE_ORDER');
        $pin = $this->params->get('sn_pin','');
        $sendPayerInfo = $this->params->get('sn_send_payer_info',1);
        $currency = $this->params->get('sn_currency',1);

        $email = !empty($data['orderinfo']['email']) ? $data['orderinfo']['email'] : '';
        $email = SNGlobal::filterVar($email,'email','');

        $phone = !empty($data['orderinfo']['phone_2']) ? $data['orderinfo']['phone_2'] : '';
        $phone = SNGlobal::filterVar($phone,'ir_phone','');

        $vars = array(
            'orderId' => (!empty($data['order_id']) ? $data['order_id'] : 0),
            'orderPaymentId' => (!empty($data['orderpayment_id']) ? $data['orderpayment_id'] : 0),
            'amount' => !empty($data['orderpayment_amount']) ? $data['orderpayment_amount'] : 0,
            'email' => $email,
            'phone' => $phone,

            'displayText' => $displayText,
            'onBeforePaymentText' => $onBeforePaymentText,
            'buttonText' => $buttonText,
            'pin' => $pin,
            'currency' => $currency,
            'sendPayerInfo' => $sendPayerInfo,

            'data' => $data,
        );

        $html = $this->_getLayout('prepayment',$vars);
        return $html;
    }

    /* After back from portal */
    function _postPayment($data)
    {
        $vars = array();
        $vars['onAfterPaymentText'] = $this->params->get('onafterpayment', '');

        $sessionData = SNApi::getData();
        $orderId = $data['order_id'];
        $urlOrderId = SNGlobal::getVar('order_id','','none','request');
        $au = SNGlobal::getVar('au','','none','request');

        // get instatnce of j2store table
        F0FTable::addIncludePath(JPATH_ADMINISTRATOR.'/components/com_j2store/tables');
        $order = F0FTable::getInstance('Order', 'J2StoreTable')->getClone();
        $order->load(array('order_id' => $orderId));

        if($order->load(array('order_id' => $orderId)))
        {
            if(!empty($sessionData) && $sessionData['order_id'] == $urlOrderId)
            {
                $bankData = array();
                foreach (!empty($sessionData['bank_callback_details']['params']) ? $sessionData['bank_callback_details']['params'] : array() as $bankParam)
                {
                    $bankData[$bankParam] = !empty($_REQUEST[$bankParam]) ? $_REQUEST[$bankParam] : '';
                }

                $data = array (
                    'pin' => $sessionData['pin'],
                    'price' => $sessionData['price'],
                    'order_id' => $sessionData['order_id'],
                    'au' => $au,
                    'bank_return' => $bankData,
                );

                list($status,$msg,$resultData) = SNApi::verify($data,'j2store');

                if($status == true)
                {
                    $order->payment_complete();
                    $order->empty_cart();

                    $bankAu = !empty($resultData['bank_au']) ? $resultData['bank_au'] : $au;
                    $msg = JText::_('SN_PAID_TRANSACTION');
                    $msg = str_replace('{REF}',$bankAu,$msg);

                    $vars['message'] = $msg . "\n";
                    $vars['status'] = 1;
                    $html = $this->_getLayout('message',$vars);
                    return $html;
                }
            }
        }

        $vars['message'] = JText::_("SN_UNPAID_TRANSACTION") . "\n";
        $vars['status'] = 0;
        $html = $this->_getLayout('message',$vars);
        return $html;
    }

    /*
	 * Before Payment, When Click On Portal
	 */
    function _renderForm( $data )
    {
        $onSelectionText = $this->params->get('onselection','');
        $vars = array(
            'onSelectionText' => $onSelectionText,
        );

        $html = $this->_getLayout('form',$vars);
        return $html;
    }

    function getPaymentStatus($paymentStatus)
    {
        $status = '';
        switch($paymentStatus)
        {
            case 1:
                $status = JText::_('J2STORE_CONFIRMED');
            break;
            case 3:
                $status = JText::_('J2STORE_FAILED');
            break;
            default:
            case 4:
                $status = JText::_('J2STORE_PENDING');
            break;
        }
        return $status;
    }
}
