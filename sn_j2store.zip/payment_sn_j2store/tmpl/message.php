<?php defined('_JEXEC') or die('Restricted access'); ?>

<div class="note">
    <p class="sn-j2store-on-after-payment-message">
        <?php echo $vars['onAfterPaymentText']; ?>
    </p>
	<p class="sn-j2store-message" <?php echo isset($vars['status']) ? 'status="'.$vars['status'].'"' : '' ?>>
        <?php echo nl2br($vars['message']); ?>
	</p>
</div>
<style>
    .sn-j2store-message[status="1"]{
        color: #26bb1e;
        font-weight: bold;
        font-size: 15px;
    }
    .sn-j2store-message[status="0"]{
        color: #ef1111;
        font-weight: bold;
        font-size: 15px;
    }
</style>
