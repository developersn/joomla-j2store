<?php
defined('_JEXEC') or die('Restricted access');
?>

<div class="note">
    <p><?php echo $vars->message; ?></p>
</div>
