<?php

defined('_JEXEC') or die('Restricted access');

require_once (JPATH_ADMINISTRATOR.'/components/com_j2store/library/plugins/payment.php');
require_once (JPATH_ADMINISTRATOR.'/components/com_j2store/helpers/j2store.php');



class plgJ2StorePayment_sn extends J2StorePaymentPlugin
{

    var $_element   = 'payment_sn';
    private $merchantCode = '';
    private $callBackUrl = '';
    private $redirectTosn = '';

    public function __construct(& $subject, $config)
    {
        parent::__construct($subject, $config);
        $this->loadLanguage( '', JPATH_ADMINISTRATOR );
        $this->merchantCode = trim($this->params->get('merchant_id'));
        $this->callBackUrl = JUri::root().'/index.php?option=com_j2store&view=checkout&task=confirmPayment&orderpayment_type=payment_sn&paction=callback';
    }

    public function _renderForm( $data )
    {
        $vars = new JObject();
        $vars->message = JText::_("J2STORE_sn_PAYMENT_MESSAGE");
        $html = $this->_getLayout('form', $vars);
        return $html;
    }

    public function _prePayment($data)
    {
        $vars = new StdClass();
        $vars->display_name = $this->params->get('display_name', '');
        $vars->onbeforepayment_text = JText::_("J2STORE_sn_PAYMENT_PREPARATION_MESSAGE");
// Security
@session_start();
$sec = uniqid();
$md = md5($sec.'vm');
// Security
		if(isset($_GET['sec']) or isset($_GET['md']) AND $mdback == $mdurl )
		{
		$amount = round($data['orderpayment_amount']);
		$return = $this->callBackUrl.'&md='.$md.'&sec='.$sec;

		$api = trim($this->params->get('merchant_id'));
		$amount = $amount/10; //Tooman
		$callbackUrl = $return;
		$orderId = $data['order_id'];
$data_string = json_encode(array(
'pin'=> $api,
'price'=> $amount,
'callback'=> $callbackUrl ,
'order_id'=> $orderId,
'ip'=> $_SERVER['REMOTE_ADDR'],
'callback_type'=>2
));

$ch = curl_init('https://developerapi.net/api/v1/request');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);


$json = json_decode($result,true);
if(!empty($json['result']) AND $json['result'] == 1)
{
// Set Session
$_SESSION[$sec] = [
	'price'=>$amount ,
	'order_id'=>$invoice_id ,
	'au'=>$json['au'] ,
];
        
            echo ('<div style="display:none">'.$json['form'].'</div>Please wait ... <script language="javascript">document.payment.submit(); </script>');
        }else{
			echo '<br>خطا: <br>'.$json['msg'];
		}		

        return $html;
    }

    public function _postPayment($data)
    {
        $vars = new JObject();
        session_start();
        
// Security
$sec=$_GET['sec'];
$mdback = md5($sec.'vm');
$mdurl=$_GET['md'];
// Security
		//get data from session
$transData = $_SESSION[$sec];
$au=$transData['au']; //

        $orderId = $transData['order_id'];
        F0FTable::addIncludePath(JPATH_ADMINISTRATOR.'/components/com_j2store/tables');
        $order = F0FTable::getInstance('Order', 'J2StoreTable')->getClone();
        $order->load(array('order_id' => $orderId));

        if($order->load(array('order_id' => $orderId))){

            $currency = J2Store::currency();
            $currencyValues= $this->getCurrency($order);
            $orderPaymentAmount = $currency->format($order->order_total, $currencyValues['currency_code'], $currencyValues['currency_value'], false);
            $orderPaymentAmount = (int)($orderPaymentAmount / 10);

            $order->add_history(JText::_('J2STORE_CALLBACK_RESPONSE_RECEIVED'));

	
		$api = $this->params->get('merchant_id');
		$amount = $orderPaymentAmount; //Tooman
		
 // CallBack
$bank_return = $_POST + $_GET ;
$data_string = json_encode(array (
'pin' => $api,
'price' => $amount,
'order_id' => $orderId,
'au' => $au,
'bank_return' =>$bank_return,
));

$ch = curl_init('https://developerapi.net/api/v1/verify');
curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
'Content-Type: application/json',
'Content-Length: ' . strlen($data_string))
);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_CONNECTTIMEOUT, 20);
$result = curl_exec($ch);
curl_close($ch);
$json = json_decode($result,true);
		if( ! empty($json['result']) and $json['result'] == 1){
			$order->payment_complete();
			$order->empty_cart();
			$message = JText::_("J2STORE_sn_PAYMENT_SUCCESS") . "\n";
			$message .= JText::_("J2STORE_sn_PAYMENT_ZP_REF") . $au;
			$vars->message = $message;
			$html = $this->_getLayout('postpayment', $vars);
			return $html;				
		}
		else{
			$vars->message = $json['msg'];
			$html = $this->_getLayout('postpayment', $vars);
			return $html;			
		}			
	}
		else{
			$vars->message = $json['msg'];
			$html = $this->_getLayout('postpayment', $vars);
			return $html;			
		}		
            return $html;

        }

        $vars->message = JText::_("J2STORE_sn_PAYMENT_PAGE_ERROR");
        $html = $this->_getLayout('postpayment', $vars);
        return $html;
    }

    private function statusText($status)
    {
        return JText::_("J2STORE_sn_PAYMENT_STATUS_" . $status );
    }
}